let currentFilename = null;
let processedFilename = null;

const uploadBox = document.getElementById('uploadBox');
const fileInput = document.getElementById('fileInput');
const originalImage = document.getElementById('originalImage');
const processedImage = document.getElementById('processedImage');
const noProcessedYet = document.getElementById('noProcessedYet');
const previewSection = document.getElementById('previewSection');
const toolsSection = document.getElementById('toolsSection');
const imageInfo = document.getElementById('imageInfo');
const loading = document.getElementById('loading');
const actionBar = document.getElementById('actionBar');

uploadBox.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', handleFileSelect);

uploadBox.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadBox.classList.add('drag-over');
});

uploadBox.addEventListener('dragleave', () => {
    uploadBox.classList.remove('drag-over');
});

uploadBox.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadBox.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
        handleFile(file);
    }
});

document.getElementById('edgeThreshold').addEventListener('input', (e) => {
    document.getElementById('thresholdValue').textContent = e.target.value;
});

document.getElementById('quality').addEventListener('input', (e) => {
    document.getElementById('qualityValue').textContent = e.target.value;
});

document.getElementById('compressQuality').addEventListener('input', (e) => {
    document.getElementById('compressQualityValue').textContent = e.target.value;
});

document.getElementById('watermarkOpacity').addEventListener('input', (e) => {
    document.getElementById('watermarkOpacityValue').textContent = e.target.value;
});

document.querySelectorAll('.tab-button').forEach(button => {
    button.addEventListener('click', () => {
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        
        button.classList.add('active');
        document.getElementById(button.dataset.tab).classList.add('active');
    });
});

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    showLoading();
    
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            currentFilename = data.filename;
            originalImage.src = `/static/uploads/${data.filename}`;
            previewSection.style.display = 'block';
            toolsSection.style.display = 'block';
            
            imageInfo.style.display = 'block';
            imageInfo.innerHTML = `
                <div><strong>Format:</strong> ${data.format}</div>
                <div><strong>Size:</strong> ${data.width} x ${data.height}</div>
                <div><strong>Mode:</strong> ${data.mode}</div>
                <div><strong>File Size:</strong> ${data.size_kb} KB</div>
            `;
            
            processedImage.style.display = 'none';
            noProcessedYet.style.display = 'block';
            actionBar.style.display = 'none';
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error uploading file: ' + error);
    });
}

function applyAutoDrawer() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const threshold = document.getElementById('edgeThreshold').value;
    
    showLoading();
    
    fetch('/auto-drawer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, threshold: threshold })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error processing: ' + error);
    });
}

function convertFormat() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const format = document.getElementById('outputFormat').value;
    const quality = document.getElementById('quality').value;
    
    showLoading();
    
    fetch('/convert-format', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, format: format, quality: quality })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function applyFilter(filterType) {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    showLoading();
    
    fetch('/apply-filter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, filter: filterType })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function applyEffect(effectType) {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    showLoading();
    
    fetch('/apply-effect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, effect: effectType })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function removeBackground() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    showLoading();
    
    fetch('/remove-background', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function compressImage() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const quality = document.getElementById('compressQuality').value;
    
    showLoading();
    
    fetch('/compress-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, quality: quality })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
            
            document.getElementById('compressionStats').style.display = 'block';
            document.getElementById('compressionStats').innerHTML = `
                <h4>Compression Results</h4>
                <p><strong>Original:</strong> ${data.original_size_kb} KB</p>
                <p><strong>Compressed:</strong> ${data.compressed_size_kb} KB</p>
                <p><strong>Savings:</strong> ${data.savings_percent}%</p>
            `;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function addWatermark() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const text = document.getElementById('watermarkText').value;
    const position = document.getElementById('watermarkPosition').value;
    const opacity = document.getElementById('watermarkOpacity').value;
    
    if (!text) {
        alert('Please enter watermark text!');
        return;
    }
    
    showLoading();
    
    fetch('/add-watermark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, text: text, position: position, opacity: opacity })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function createMeme() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const topText = document.getElementById('memeTopText').value;
    const bottomText = document.getElementById('memeBottomText').value;
    
    if (!topText && !bottomText) {
        alert('Please enter at least one text!');
        return;
    }
    
    showLoading();
    
    fetch('/create-meme', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, topText: topText, bottomText: bottomText })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function resizeImage() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const width = document.getElementById('resizeWidth').value;
    const height = document.getElementById('resizeHeight').value;
    const maintainRatio = document.getElementById('maintainRatio').checked;
    
    if (!width || !height) {
        alert('Please enter width and height!');
        return;
    }
    
    showLoading();
    
    fetch('/resize-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, width: width, height: height, maintainRatio: maintainRatio })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function rotateImage() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    const angle = document.getElementById('rotateAngle').value;
    
    showLoading();
    
    fetch('/rotate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, angle: angle })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showProcessedImage(data.processed_url);
            processedFilename = data.processed_filename;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function getHistogram() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    showLoading();
    
    fetch('/get-histogram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            document.getElementById('analysisResults').innerHTML = `
                <h4>RGB Histogram</h4>
                <img src="${data.processed_url}" style="max-width: 100%; border-radius: 8px;">
            `;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function getColorPalette() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    showLoading();
    
    fetch('/get-color-palette', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename, numColors: 5 })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            let swatches = '';
            data.colors.forEach(color => {
                swatches += `
                    <div class="color-swatch" style="background-color: ${color.hex};">
                        ${color.hex}
                    </div>
                `;
            });
            
            document.getElementById('analysisResults').innerHTML = `
                <h4>Color Palette</h4>
                <img src="${data.palette_url}" style="max-width: 100%; border-radius: 8px; margin-bottom: 1rem;">
                <div class="color-palette">${swatches}</div>
            `;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function getMetadata() {
    if (!currentFilename) {
        alert('Please upload an image first!');
        return;
    }
    
    showLoading();
    
    fetch('/get-metadata', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentFilename })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            const metadata = data.metadata;
            document.getElementById('analysisResults').innerHTML = `
                <h4>Image Metadata</h4>
                <table class="metadata-table">
                    <tr><td>Filename</td><td>${metadata.filename}</td></tr>
                    <tr><td>Format</td><td>${metadata.format}</td></tr>
                    <tr><td>Mode</td><td>${metadata.mode}</td></tr>
                    <tr><td>Dimensions</td><td>${metadata.size}</td></tr>
                    <tr><td>File Size</td><td>${metadata.file_size_kb} KB</td></tr>
                </table>
            `;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error: ' + error);
    });
}

function showProcessedImage(url) {
    processedImage.src = url;
    processedImage.style.display = 'block';
    noProcessedYet.style.display = 'none';
    actionBar.style.display = 'flex';
}

function downloadProcessed() {
    if (processedFilename) {
        window.location.href = `/download/${processedFilename}`;
    }
}

function resetAll() {
    location.reload();
}

function showLoading() {
    loading.style.display = 'flex';
}

function hideLoading() {
    loading.style.display = 'none';
}

let batchUploadedFiles = [];

document.getElementById('batchFileInput').addEventListener('change', function(e) {
    const files = e.target.files;
    if (files.length > 0) {
        const fileList = document.getElementById('batchFiles');
        fileList.innerHTML = '';
        
        for (let file of files) {
            const li = document.createElement('li');
            li.style.padding = '0.5rem';
            li.style.borderBottom = '1px solid #ddd';
            li.innerHTML = `📄 ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
            fileList.appendChild(li);
        }
        
        document.getElementById('batchFileList').style.display = 'block';
    }
});

function processBatch() {
    const fileInput = document.getElementById('batchFileInput');
    const files = fileInput.files;
    
    if (files.length === 0) {
        alert('Please select images first!');
        return;
    }
    
    const operation = document.getElementById('batchOperation').value;
    
    showLoading();
    
    const formData = new FormData();
    for (let file of files) {
        formData.append('files[]', file);
    }
    
    fetch('/batch-upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            batchUploadedFiles = data.files.map(f => f.filename);
            
            return fetch('/batch-process', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    filenames: batchUploadedFiles,
                    operation: operation
                })
            });
        } else {
            throw new Error(data.error);
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            document.getElementById('batchResults').style.display = 'block';
            document.getElementById('batchStatus').innerHTML = `
                <p style="color: #28a745; font-weight: bold;">
                    ✅ Successfully processed ${data.successful} of ${data.total} images
                </p>
            `;
            
            let downloads = '';
            data.processed.forEach((file, index) => {
                if (!file.error) {
                    downloads += `
                        <div style="margin: 0.5rem 0;">
                            <a href="/download/${file.processed}" class="btn btn-secondary" style="display: inline-block; text-decoration: none; margin-right: 0.5rem;">
                                💾 Download ${index + 1}
                            </a>
                            <span>${file.original}</span>
                        </div>
                    `;
                }
            });
            
            document.getElementById('batchDownloads').innerHTML = downloads;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        hideLoading();
        alert('Error processing batch: ' + error);
    });
}
