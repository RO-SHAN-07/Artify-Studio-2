from flask import Flask, render_template, request, jsonify, send_file, send_from_directory
from flask_cors import CORS
from PIL import Image, ImageFilter, ImageEnhance, ImageOps, ImageDraw, ImageFont, ImageStat
import cv2
import numpy as np
import os
import io
import base64
from werkzeug.utils import secure_filename

try:
    from rembg import remove
    REMBG_AVAILABLE = True
except ImportError:
    REMBG_AVAILABLE = False
    print("Note: rembg not available. Background removal feature will be disabled.")

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['PROCESSED_FOLDER'] = 'static/processed'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROCESSED_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'tiff'}

try:
    RESAMPLE_FILTER = Image.Resampling.LANCZOS
except AttributeError:
    RESAMPLE_FILTER = Image.LANCZOS

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def image_to_base64(img):
    buffered = io.BytesIO()
    img.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        img = Image.open(filepath)
        return jsonify({
            'success': True,
            'filename': filename,
            'width': img.width,
            'height': img.height,
            'format': img.format,
            'mode': img.mode,
            'size_kb': os.path.getsize(filepath) // 1024
        })
    
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/auto-drawer', methods=['POST'])
def auto_drawer():
    data = request.json
    filename = data.get('filename')
    threshold = data.get('threshold', 100)
    
    if not filename:
        return jsonify({'error': 'No filename provided'}), 400
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    jpg_path = os.path.join(app.config['PROCESSED_FOLDER'], 'converted_temp.jpg')
    img.save(jpg_path, 'JPEG', quality=95)
    
    img_jpg = Image.open(jpg_path)
    img_array = np.array(img_jpg)
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, int(threshold), int(threshold) * 2)
    
    processed_img = Image.fromarray(edges)
    output_filename = f"autodraw_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    processed_img.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/convert-format', methods=['POST'])
def convert_format():
    data = request.json
    filename = data.get('filename')
    output_format = data.get('format', 'PNG')
    quality = data.get('quality', 95)
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    if img.mode == 'RGBA' and output_format in ['JPEG', 'BMP']:
        img = img.convert('RGB')
    
    output_ext = output_format.lower().replace('jpeg', 'jpg')
    output_filename = f"converted_{filename.rsplit('.', 1)[0]}.{output_ext}"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    
    if output_format == 'JPEG':
        img.save(output_path, 'JPEG', quality=int(quality))
    else:
        img.save(output_path, output_format)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/apply-filter', methods=['POST'])
def apply_filter():
    data = request.json
    filename = data.get('filename')
    filter_type = data.get('filter')
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    if filter_type == 'grayscale':
        img = img.convert('L').convert('RGB')
    elif filter_type == 'blur':
        img = img.filter(ImageFilter.GaussianBlur(radius=5))
    elif filter_type == 'sharpen':
        img = img.filter(ImageFilter.SHARPEN)
    elif filter_type == 'edges':
        img = img.filter(ImageFilter.FIND_EDGES)
    elif filter_type == 'emboss':
        img = img.filter(ImageFilter.EMBOSS)
    elif filter_type == 'contour':
        img = img.filter(ImageFilter.CONTOUR)
    elif filter_type == 'smooth':
        img = img.filter(ImageFilter.SMOOTH_MORE)
    elif filter_type == 'detail':
        img = img.filter(ImageFilter.DETAIL)
    
    output_filename = f"filter_{filter_type}_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    img.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/apply-effect', methods=['POST'])
def apply_effect():
    data = request.json
    filename = data.get('filename')
    effect_type = data.get('effect')
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath).convert('RGB')
    
    if effect_type == 'sepia':
        pixels = img.load()
        for i in range(img.width):
            for j in range(img.height):
                r, g, b = pixels[i, j]
                tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                pixels[i, j] = (min(255, tr), min(255, tg), min(255, tb))
    elif effect_type == 'negative':
        img = ImageOps.invert(img)
    elif effect_type == 'brighten':
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(1.5)
    elif effect_type == 'darken':
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(0.6)
    elif effect_type == 'contrast':
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(2.0)
    elif effect_type == 'posterize':
        img = ImageOps.posterize(img, 3)
    elif effect_type == 'solarize':
        img = ImageOps.solarize(img, threshold=128)
    elif effect_type == 'vintage':
        img = img.convert('L').convert('RGB')
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(0.8)
    
    output_filename = f"effect_{effect_type}_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    img.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/remove-background', methods=['POST'])
def remove_background():
    if not REMBG_AVAILABLE:
        return jsonify({
            'error': 'Background removal feature is not available. Install rembg package to enable this feature.'
        }), 501
    
    data = request.json
    filename = data.get('filename')
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    with open(filepath, 'rb') as input_file:
        input_data = input_file.read()
    
    output_data = remove(input_data)
    
    output_filename = f"nobg_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    
    with open(output_path, 'wb') as output_file:
        output_file.write(output_data)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/compress-image', methods=['POST'])
def compress_image():
    data = request.json
    filename = data.get('filename')
    quality = data.get('quality', 50)
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    if img.mode == 'RGBA':
        img = img.convert('RGB')
    
    output_filename = f"compressed_{filename.rsplit('.', 1)[0]}.jpg"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    img.save(output_path, 'JPEG', quality=int(quality), optimize=True)
    
    original_size = os.path.getsize(filepath) / 1024
    compressed_size = os.path.getsize(output_path) / 1024
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename,
        'original_size_kb': round(original_size, 2),
        'compressed_size_kb': round(compressed_size, 2),
        'savings_percent': round((1 - compressed_size / original_size) * 100, 1)
    })

@app.route('/add-watermark', methods=['POST'])
def add_watermark():
    data = request.json
    filename = data.get('filename')
    watermark_text = data.get('text', 'Watermark')
    position = data.get('position', 'bottom-right')
    opacity = data.get('opacity', 128)
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath).convert('RGBA')
    
    txt_layer = Image.new('RGBA', img.size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(txt_layer)
    
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 40)
    except:
        font = ImageFont.load_default()
    
    bbox = draw.textbbox((0, 0), watermark_text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    if position == 'bottom-right':
        text_position = (img.width - text_width - 20, img.height - text_height - 20)
    elif position == 'bottom-left':
        text_position = (20, img.height - text_height - 20)
    elif position == 'top-right':
        text_position = (img.width - text_width - 20, 20)
    elif position == 'top-left':
        text_position = (20, 20)
    else:
        text_position = ((img.width - text_width) // 2, (img.height - text_height) // 2)
    
    draw.text(text_position, watermark_text, fill=(255, 255, 255, int(opacity)), font=font)
    
    watermarked = Image.alpha_composite(img, txt_layer)
    watermarked = watermarked.convert('RGB')
    
    output_filename = f"watermark_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    watermarked.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/create-meme', methods=['POST'])
def create_meme():
    data = request.json
    filename = data.get('filename')
    top_text = data.get('topText', '')
    bottom_text = data.get('bottomText', '')
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath).convert('RGB')
    
    draw = ImageDraw.Draw(img)
    
    try:
        font_size = max(30, img.width // 15)
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    def draw_text_with_outline(draw, text, position, font):
        x, y = position
        for adj_x in range(-2, 3):
            for adj_y in range(-2, 3):
                draw.text((x + adj_x, y + adj_y), text, font=font, fill="black")
        draw.text((x, y), text, font=font, fill="white")
    
    if top_text:
        bbox = draw.textbbox((0, 0), top_text, font=font)
        text_width = bbox[2] - bbox[0]
        draw_text_with_outline(draw, top_text, ((img.width - text_width) // 2, 20), font)
    
    if bottom_text:
        bbox = draw.textbbox((0, 0), bottom_text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        draw_text_with_outline(draw, bottom_text, ((img.width - text_width) // 2, img.height - text_height - 20), font)
    
    output_filename = f"meme_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    img.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/resize-image', methods=['POST'])
def resize_image():
    data = request.json
    filename = data.get('filename')
    width = data.get('width')
    height = data.get('height')
    maintain_ratio = data.get('maintainRatio', True)
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    if maintain_ratio:
        img.thumbnail((int(width), int(height)), RESAMPLE_FILTER)
    else:
        img = img.resize((int(width), int(height)), RESAMPLE_FILTER)
    
    output_filename = f"resized_{width}x{height}_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    img.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename,
        'new_width': img.width,
        'new_height': img.height
    })

@app.route('/rotate-image', methods=['POST'])
def rotate_image():
    data = request.json
    filename = data.get('filename')
    angle = data.get('angle', 90)
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    rotated = img.rotate(-int(angle), expand=True)
    
    output_filename = f"rotated_{angle}_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    rotated.save(output_path)
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/get-histogram', methods=['POST'])
def get_histogram():
    data = request.json
    filename = data.get('filename')
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath).convert('RGB')
    
    plt.figure(figsize=(10, 4))
    
    colors = ['red', 'green', 'blue']
    for i, color in enumerate(colors):
        histogram = img.split()[i].histogram()
        plt.plot(histogram, color=color, alpha=0.7, linewidth=2)
    
    plt.xlabel('Pixel Value')
    plt.ylabel('Frequency')
    plt.title('RGB Histogram')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    output_filename = f"histogram_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    plt.savefig(output_path, dpi=100, bbox_inches='tight')
    plt.close()
    
    return jsonify({
        'success': True,
        'processed_url': f'/static/processed/{output_filename}',
        'processed_filename': output_filename
    })

@app.route('/get-color-palette', methods=['POST'])
def get_color_palette():
    data = request.json
    filename = data.get('filename')
    num_colors = data.get('numColors', 5)
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath).convert('RGB')
    
    img_small = img.resize((100, 100))
    
    result = img_small.quantize(colors=int(num_colors))
    palette = result.getpalette()
    
    colors = []
    for i in range(int(num_colors)):
        r, g, b = palette[i*3:i*3+3]
        colors.append({
            'hex': f'#{r:02x}{g:02x}{b:02x}',
            'rgb': f'rgb({r}, {g}, {b})'
        })
    
    palette_img = Image.new('RGB', (500, 100))
    draw = ImageDraw.Draw(palette_img)
    color_width = 500 // int(num_colors)
    
    for i, color_info in enumerate(colors):
        r, g, b = int(color_info['hex'][1:3], 16), int(color_info['hex'][3:5], 16), int(color_info['hex'][5:7], 16)
        draw.rectangle([i * color_width, 0, (i + 1) * color_width, 100], fill=(r, g, b))
    
    output_filename = f"palette_{filename.rsplit('.', 1)[0]}.png"
    output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
    palette_img.save(output_path)
    
    return jsonify({
        'success': True,
        'colors': colors,
        'palette_url': f'/static/processed/{output_filename}'
    })

@app.route('/get-metadata', methods=['POST'])
def get_metadata():
    data = request.json
    filename = data.get('filename')
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    img = Image.open(filepath)
    
    exif_data = img.getexif() if hasattr(img, 'getexif') else {}
    
    metadata = {
        'filename': filename,
        'format': img.format,
        'mode': img.mode,
        'size': f"{img.width} x {img.height}",
        'width': img.width,
        'height': img.height,
        'file_size_kb': round(os.path.getsize(filepath) / 1024, 2),
        'exif': {str(k): str(v) for k, v in exif_data.items()} if exif_data else {}
    }
    
    return jsonify({'success': True, 'metadata': metadata})

@app.route('/batch-upload', methods=['POST'])
def batch_upload():
    if 'files[]' not in request.files:
        return jsonify({'error': 'No files uploaded'}), 400
    
    files = request.files.getlist('files[]')
    uploaded_files = []
    
    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            filename = f"{timestamp}_{filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            img = Image.open(filepath)
            uploaded_files.append({
                'filename': filename,
                'original_name': file.filename,
                'width': img.width,
                'height': img.height,
                'format': img.format
            })
    
    return jsonify({
        'success': True,
        'files': uploaded_files,
        'count': len(uploaded_files)
    })

@app.route('/batch-process', methods=['POST'])
def batch_process():
    data = request.json
    filenames = data.get('filenames', [])
    operation = data.get('operation')
    params = data.get('params', {})
    
    if not filenames or not operation:
        return jsonify({'error': 'Missing filenames or operation'}), 400
    
    processed_files = []
    
    for filename in filenames:
        try:
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            img = Image.open(filepath)
            
            if operation == 'grayscale':
                img = img.convert('L').convert('RGB')
            elif operation == 'resize_50':
                new_size = (img.width // 2, img.height // 2)
                img = img.resize(new_size, RESAMPLE_FILTER)
            elif operation == 'blur':
                img = img.filter(ImageFilter.GaussianBlur(radius=3))
            elif operation == 'sharpen':
                img = img.filter(ImageFilter.SHARPEN)
            elif operation == 'sepia':
                img = img.convert('RGB')
                pixels = img.load()
                for i in range(img.width):
                    for j in range(img.height):
                        r, g, b = pixels[i, j]
                        tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                        tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                        tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                        pixels[i, j] = (min(255, tr), min(255, tg), min(255, tb))
            elif operation == 'edge_detect':
                img = img.filter(ImageFilter.FIND_EDGES)
            
            output_filename = f"batch_{operation}_{filename}"
            output_path = os.path.join(app.config['PROCESSED_FOLDER'], output_filename)
            img.save(output_path)
            
            processed_files.append({
                'original': filename,
                'processed': output_filename,
                'url': f'/static/processed/{output_filename}'
            })
            
        except Exception as e:
            processed_files.append({
                'original': filename,
                'error': str(e)
            })
    
    return jsonify({
        'success': True,
        'processed': processed_files,
        'total': len(filenames),
        'successful': len([f for f in processed_files if 'error' not in f])
    })

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['PROCESSED_FOLDER'], filename, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
