import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageFilter, ImageEnhance, ImageOps
import cv2
import numpy as np
import os
import multiprocessing
import turtle
from pathlib import Path

try:
    RESAMPLE_FILTER = Image.Resampling.LANCZOS
except AttributeError:
    RESAMPLE_FILTER = Image.LANCZOS

class ImageToolkit:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Image Toolkit - Advanced Image Processing Tools")
        self.root.geometry("1200x800")
        
        self.current_image = None
        self.current_image_path = None
        self.processed_image = None
        self.recent_files = []
        self.active_processes = []
        
        self.setup_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def setup_ui(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        title_label = ttk.Label(main_frame, text="🎨 Python Image Toolkit", 
                               font=('Helvetica', 20, 'bold'))
        title_label.grid(row=0, column=0, pady=10)
        
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.create_auto_drawer_tab()
        self.create_converter_tab()
        self.create_filters_tab()
        self.create_effects_tab()
        self.create_batch_tab()
        
        status_frame = ttk.Frame(main_frame)
        status_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        self.status_label = ttk.Label(status_frame, text="Ready", relief=tk.SUNKEN)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        self.progress = ttk.Progressbar(status_frame, mode='indeterminate')
        self.progress.pack(side=tk.RIGHT, padx=5)
        
    def create_auto_drawer_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="🖊️ Auto-Drawer")
        
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(1, weight=1)
        
        control_frame = ttk.LabelFrame(tab, text="Controls", padding="10")
        control_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        ttk.Button(control_frame, text="📁 Load Image", 
                  command=self.load_image_for_drawer).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="🎨 Start Drawing", 
                  command=self.start_auto_drawing).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="💾 Save Processed", 
                  command=self.save_processed_drawer).pack(side=tk.LEFT, padx=5)
        
        ttk.Label(control_frame, text="Edge Threshold:").pack(side=tk.LEFT, padx=10)
        self.edge_threshold = tk.IntVar(value=100)
        ttk.Scale(control_frame, from_=50, to=200, variable=self.edge_threshold,
                 orient=tk.HORIZONTAL, length=150).pack(side=tk.LEFT, padx=5)
        
        preview_left = ttk.LabelFrame(tab, text="Original Image", padding="10")
        preview_left.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.drawer_canvas_left = tk.Canvas(preview_left, bg='white', width=500, height=500)
        self.drawer_canvas_left.pack(fill=tk.BOTH, expand=True)
        
        preview_right = ttk.LabelFrame(tab, text="Processed (B&W Edges)", padding="10")
        preview_right.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.drawer_canvas_right = tk.Canvas(preview_right, bg='white', width=500, height=500)
        self.drawer_canvas_right.pack(fill=tk.BOTH, expand=True)
        
        info_frame = ttk.LabelFrame(tab, text="Information", padding="10")
        info_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), padx=5, pady=5)
        
        info_text = """How to use Auto-Drawer:
1. Load any color image (PNG, JPG, WEBP, BMP supported)
2. Adjust edge threshold if needed (higher = more detail)
3. Click 'Start Drawing' to see Turtle Graphics animate the drawing
4. The tool automatically converts to JPG, applies edge detection, and draws the outline"""
        
        ttk.Label(info_frame, text=info_text, justify=tk.LEFT).pack()
        
    def create_converter_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="🔄 Format Converter")
        
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(2, weight=1)
        
        control_frame = ttk.LabelFrame(tab, text="Convert Settings", padding="10")
        control_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        ttk.Button(control_frame, text="📁 Select Image(s)", 
                  command=self.load_images_for_converter).pack(side=tk.LEFT, padx=5)
        
        ttk.Label(control_frame, text="Output Format:").pack(side=tk.LEFT, padx=10)
        self.output_format = tk.StringVar(value="JPEG")
        formats = ["JPEG", "PNG", "WEBP", "BMP", "TIFF"]
        ttk.Combobox(control_frame, textvariable=self.output_format, 
                    values=formats, state='readonly', width=10).pack(side=tk.LEFT, padx=5)
        
        ttk.Label(control_frame, text="Quality:").pack(side=tk.LEFT, padx=10)
        self.quality = tk.IntVar(value=95)
        ttk.Scale(control_frame, from_=1, to=100, variable=self.quality,
                 orient=tk.HORIZONTAL, length=150).pack(side=tk.LEFT, padx=5)
        ttk.Label(control_frame, textvariable=self.quality).pack(side=tk.LEFT)
        
        ttk.Button(control_frame, text="🔄 Convert", 
                  command=self.convert_images).pack(side=tk.LEFT, padx=20)
        
        files_frame = ttk.LabelFrame(tab, text="Selected Files", padding="10")
        files_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        self.converter_listbox = tk.Listbox(files_frame, height=6)
        self.converter_listbox.pack(fill=tk.BOTH, expand=True)
        
        preview_frame = ttk.LabelFrame(tab, text="Preview", padding="10")
        preview_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.converter_canvas = tk.Canvas(preview_frame, bg='white', height=400)
        self.converter_canvas.pack(fill=tk.BOTH, expand=True)
        
    def create_filters_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="🎭 Filters")
        
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(1, weight=1)
        
        control_frame = ttk.LabelFrame(tab, text="Filter Controls", padding="10")
        control_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        ttk.Button(control_frame, text="📁 Load Image", 
                  command=self.load_image_for_filters).pack(side=tk.LEFT, padx=5)
        
        filter_buttons_frame = ttk.Frame(control_frame)
        filter_buttons_frame.pack(side=tk.LEFT, padx=20)
        
        ttk.Button(filter_buttons_frame, text="Grayscale", 
                  command=lambda: self.apply_filter('grayscale')).grid(row=0, column=0, padx=2)
        ttk.Button(filter_buttons_frame, text="Blur", 
                  command=lambda: self.apply_filter('blur')).grid(row=0, column=1, padx=2)
        ttk.Button(filter_buttons_frame, text="Sharpen", 
                  command=lambda: self.apply_filter('sharpen')).grid(row=0, column=2, padx=2)
        ttk.Button(filter_buttons_frame, text="Edge Detect", 
                  command=lambda: self.apply_filter('edges')).grid(row=1, column=0, padx=2)
        ttk.Button(filter_buttons_frame, text="Emboss", 
                  command=lambda: self.apply_filter('emboss')).grid(row=1, column=1, padx=2)
        ttk.Button(filter_buttons_frame, text="Contour", 
                  command=lambda: self.apply_filter('contour')).grid(row=1, column=2, padx=2)
        
        ttk.Button(control_frame, text="💾 Save Result", 
                  command=self.save_filtered_image).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="↩️ Reset", 
                  command=self.reset_filter).pack(side=tk.LEFT, padx=5)
        
        preview_left = ttk.LabelFrame(tab, text="Original", padding="10")
        preview_left.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.filter_canvas_left = tk.Canvas(preview_left, bg='white', width=500, height=500)
        self.filter_canvas_left.pack(fill=tk.BOTH, expand=True)
        
        preview_right = ttk.LabelFrame(tab, text="Filtered", padding="10")
        preview_right.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.filter_canvas_right = tk.Canvas(preview_right, bg='white', width=500, height=500)
        self.filter_canvas_right.pack(fill=tk.BOTH, expand=True)
        
    def create_effects_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="✨ Effects")
        
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(1, weight=1)
        
        control_frame = ttk.LabelFrame(tab, text="Effect Controls", padding="10")
        control_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        ttk.Button(control_frame, text="📁 Load Image", 
                  command=self.load_image_for_effects).pack(side=tk.LEFT, padx=5)
        
        effect_buttons_frame = ttk.Frame(control_frame)
        effect_buttons_frame.pack(side=tk.LEFT, padx=20)
        
        ttk.Button(effect_buttons_frame, text="Sepia", 
                  command=lambda: self.apply_effect('sepia')).grid(row=0, column=0, padx=2)
        ttk.Button(effect_buttons_frame, text="Negative", 
                  command=lambda: self.apply_effect('negative')).grid(row=0, column=1, padx=2)
        ttk.Button(effect_buttons_frame, text="Brighten", 
                  command=lambda: self.apply_effect('brighten')).grid(row=0, column=2, padx=2)
        ttk.Button(effect_buttons_frame, text="Darken", 
                  command=lambda: self.apply_effect('darken')).grid(row=1, column=0, padx=2)
        ttk.Button(effect_buttons_frame, text="High Contrast", 
                  command=lambda: self.apply_effect('contrast')).grid(row=1, column=1, padx=2)
        ttk.Button(effect_buttons_frame, text="Posterize", 
                  command=lambda: self.apply_effect('posterize')).grid(row=1, column=2, padx=2)
        
        ttk.Button(control_frame, text="💾 Save Result", 
                  command=self.save_effect_image).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="↩️ Reset", 
                  command=self.reset_effect).pack(side=tk.LEFT, padx=5)
        
        preview_left = ttk.LabelFrame(tab, text="Original", padding="10")
        preview_left.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.effect_canvas_left = tk.Canvas(preview_left, bg='white', width=500, height=500)
        self.effect_canvas_left.pack(fill=tk.BOTH, expand=True)
        
        preview_right = ttk.LabelFrame(tab, text="Effect Applied", padding="10")
        preview_right.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5, pady=5)
        
        self.effect_canvas_right = tk.Canvas(preview_right, bg='white', width=500, height=500)
        self.effect_canvas_right.pack(fill=tk.BOTH, expand=True)
        
    def create_batch_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="📦 Batch Processing")
        
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)
        
        control_frame = ttk.LabelFrame(tab, text="Batch Settings", padding="10")
        control_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        ttk.Button(control_frame, text="📁 Select Multiple Images", 
                  command=self.load_batch_images).pack(side=tk.LEFT, padx=5)
        
        ttk.Label(control_frame, text="Apply:").pack(side=tk.LEFT, padx=10)
        self.batch_operation = tk.StringVar(value="Grayscale")
        operations = ["Grayscale", "Resize (50%)", "Blur", "Sharpen", "Edge Detect", "Sepia"]
        ttk.Combobox(control_frame, textvariable=self.batch_operation, 
                    values=operations, state='readonly', width=15).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(control_frame, text="▶️ Process All", 
                  command=self.process_batch).pack(side=tk.LEFT, padx=20)
        
        files_frame = ttk.LabelFrame(tab, text="Files Queue", padding="10")
        files_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5, padx=5)
        
        scrollbar = ttk.Scrollbar(files_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.batch_listbox = tk.Listbox(files_frame, yscrollcommand=scrollbar.set)
        self.batch_listbox.pack(fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.batch_listbox.yview)
        
        info_frame = ttk.LabelFrame(tab, text="Batch Info", padding="10")
        info_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), padx=5, pady=5)
        
        self.batch_info_label = ttk.Label(info_frame, 
                                         text="No files loaded. Processed files will be saved in 'batch_output' folder.")
        self.batch_info_label.pack()
        
    def load_image_for_drawer(self):
        filepath = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All Files", "*.*")]
        )
        if filepath:
            self.current_image_path = filepath
            self.update_status(f"Loaded: {os.path.basename(filepath)}")
            
            img = Image.open(filepath)
            self.current_image = img.copy()
            
            self.display_image(img, self.drawer_canvas_left)
            
            self.process_image_for_drawing()
            
    def process_image_for_drawing(self):
        if self.current_image is None:
            return
            
        self.update_status("Converting to JPG format...")
        
        img = self.current_image.copy()
        
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        jpg_path = "converted_image.jpg"
        img.save(jpg_path, "JPEG", quality=95)
        self.update_status(f"Saved as {jpg_path}")
        
        self.update_status("Processing image for drawing...")
        
        img_jpg = Image.open(jpg_path)
        img_array = np.array(img_jpg)
        
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        threshold_val = self.edge_threshold.get()
        edges = cv2.Canny(gray, threshold_val, threshold_val * 2)
        
        self.processed_image = Image.fromarray(edges)
        
        self.display_image(self.processed_image, self.drawer_canvas_right)
        
        self.update_status("Image processed and ready for drawing")
        
    def start_auto_drawing(self):
        if self.processed_image is None:
            messagebox.showwarning("No Image", "Please load an image first!")
            return
        
        temp_path = "bw_image.jpg"
        draw_img = self.processed_image.copy()
        draw_img = draw_img.resize((300, 300), RESAMPLE_FILTER)
        draw_img.save(temp_path, "JPEG")
        
        self.update_status("Starting Turtle Graphics drawing in new window...")
        messagebox.showinfo("Auto-Drawer", 
                          "A new Turtle Graphics window will open.\n" +
                          "The drawing will be animated automatically.\n" +
                          "Close the turtle window when finished to return to the main app.")
        
        self.cleanup_finished_processes()
        
        process = multiprocessing.Process(target=draw_with_turtle_process, args=(temp_path,))
        process.start()
        self.active_processes.append(process)
            
    def save_processed_drawer(self):
        if self.processed_image is None:
            messagebox.showwarning("No Image", "No processed image to save!")
            return
            
        filepath = filedialog.asksaveasfilename(
            defaultextension=".jpg",
            filetypes=[("JPEG", "*.jpg"), ("PNG", "*.png"), ("All Files", "*.*")]
        )
        
        if filepath:
            self.processed_image.save(filepath)
            self.update_status(f"Saved: {os.path.basename(filepath)}")
            messagebox.showinfo("Success", "Processed image saved successfully!")
            
    def load_images_for_converter(self):
        filepaths = filedialog.askopenfilenames(
            title="Select Image(s)",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All Files", "*.*")]
        )
        
        if filepaths:
            self.converter_listbox.delete(0, tk.END)
            for path in filepaths:
                self.converter_listbox.insert(tk.END, path)
            
            if filepaths:
                img = Image.open(filepaths[0])
                self.display_image(img, self.converter_canvas)
                self.update_status(f"Loaded {len(filepaths)} file(s)")
                
    def convert_images(self):
        if self.converter_listbox.size() == 0:
            messagebox.showwarning("No Files", "Please select images to convert!")
            return
            
        output_dir = filedialog.askdirectory(title="Select Output Folder")
        if not output_dir:
            return
            
        output_format = self.output_format.get()
        quality = self.quality.get()
        
        self.start_progress()
        
        converted = 0
        total = self.converter_listbox.size()
        
        for i in range(total):
            filepath = self.converter_listbox.get(i)
            try:
                img = Image.open(filepath)
                
                if img.mode == 'RGBA' and output_format in ['JPEG', 'BMP']:
                    img = img.convert('RGB')
                
                base_name = os.path.splitext(os.path.basename(filepath))[0]
                ext = output_format.lower().replace('jpeg', 'jpg')
                output_path = os.path.join(output_dir, f"{base_name}.{ext}")
                
                if output_format == 'JPEG':
                    img.save(output_path, 'JPEG', quality=quality)
                else:
                    img.save(output_path, output_format)
                
                converted += 1
                self.update_status(f"Converting: {converted}/{total}")
                
            except Exception as e:
                print(f"Error converting {filepath}: {e}")
        
        self.stop_progress()
        self.update_status(f"Converted {converted} of {total} images")
        messagebox.showinfo("Complete", f"Successfully converted {converted} images!")
        
    def load_image_for_filters(self):
        filepath = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All Files", "*.*")]
        )
        if filepath:
            self.current_image_path = filepath
            self.current_image = Image.open(filepath)
            self.processed_image = self.current_image.copy()
            
            self.display_image(self.current_image, self.filter_canvas_left)
            self.display_image(self.current_image, self.filter_canvas_right)
            
            self.update_status(f"Loaded: {os.path.basename(filepath)}")
            
    def apply_filter(self, filter_type):
        if self.current_image is None:
            messagebox.showwarning("No Image", "Please load an image first!")
            return
            
        img = self.current_image.copy()
        
        if filter_type == 'grayscale':
            img = img.convert('L').convert('RGB')
        elif filter_type == 'blur':
            img = img.filter(ImageFilter.GaussianBlur(radius=5))
        elif filter_type == 'sharpen':
            img = img.filter(ImageFilter.SHARPEN)
        elif filter_type == 'edges':
            img = img.filter(ImageFilter.FIND_EDGES)
        elif filter_type == 'emboss':
            img = img.filter(ImageFilter.EMBOSS)
        elif filter_type == 'contour':
            img = img.filter(ImageFilter.CONTOUR)
            
        self.processed_image = img
        self.display_image(img, self.filter_canvas_right)
        self.update_status(f"Applied {filter_type} filter")
        
    def reset_filter(self):
        if self.current_image is not None:
            self.display_image(self.current_image, self.filter_canvas_right)
            self.processed_image = self.current_image.copy()
            self.update_status("Filter reset")
            
    def save_filtered_image(self):
        if self.processed_image is None:
            messagebox.showwarning("No Image", "No filtered image to save!")
            return
            
        filepath = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg"), ("All Files", "*.*")]
        )
        
        if filepath:
            self.processed_image.save(filepath)
            self.update_status(f"Saved: {os.path.basename(filepath)}")
            messagebox.showinfo("Success", "Filtered image saved!")
            
    def load_image_for_effects(self):
        filepath = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All Files", "*.*")]
        )
        if filepath:
            self.current_image_path = filepath
            self.current_image = Image.open(filepath)
            self.processed_image = self.current_image.copy()
            
            self.display_image(self.current_image, self.effect_canvas_left)
            self.display_image(self.current_image, self.effect_canvas_right)
            
            self.update_status(f"Loaded: {os.path.basename(filepath)}")
            
    def apply_effect(self, effect_type):
        if self.current_image is None:
            messagebox.showwarning("No Image", "Please load an image first!")
            return
            
        img = self.current_image.copy()
        
        if effect_type == 'sepia':
            img = img.convert('RGB')
            pixels = img.load()
            for i in range(img.width):
                for j in range(img.height):
                    r, g, b = pixels[i, j]
                    tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                    tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                    tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                    pixels[i, j] = (min(255, tr), min(255, tg), min(255, tb))
        elif effect_type == 'negative':
            img = ImageOps.invert(img.convert('RGB'))
        elif effect_type == 'brighten':
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(1.5)
        elif effect_type == 'darken':
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(0.6)
        elif effect_type == 'contrast':
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(2.0)
        elif effect_type == 'posterize':
            img = ImageOps.posterize(img.convert('RGB'), 3)
            
        self.processed_image = img
        self.display_image(img, self.effect_canvas_right)
        self.update_status(f"Applied {effect_type} effect")
        
    def reset_effect(self):
        if self.current_image is not None:
            self.display_image(self.current_image, self.effect_canvas_right)
            self.processed_image = self.current_image.copy()
            self.update_status("Effect reset")
            
    def save_effect_image(self):
        if self.processed_image is None:
            messagebox.showwarning("No Image", "No effect image to save!")
            return
            
        filepath = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg"), ("All Files", "*.*")]
        )
        
        if filepath:
            self.processed_image.save(filepath)
            self.update_status(f"Saved: {os.path.basename(filepath)}")
            messagebox.showinfo("Success", "Effect image saved!")
            
    def load_batch_images(self):
        filepaths = filedialog.askopenfilenames(
            title="Select Multiple Images",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All Files", "*.*")]
        )
        
        if filepaths:
            self.batch_listbox.delete(0, tk.END)
            for path in filepaths:
                self.batch_listbox.insert(tk.END, path)
            
            self.batch_info_label.config(text=f"{len(filepaths)} files loaded")
            self.update_status(f"Loaded {len(filepaths)} files for batch processing")
            
    def process_batch(self):
        if self.batch_listbox.size() == 0:
            messagebox.showwarning("No Files", "Please select images to process!")
            return
            
        output_dir = "batch_output"
        os.makedirs(output_dir, exist_ok=True)
        
        operation = self.batch_operation.get()
        total = self.batch_listbox.size()
        
        self.start_progress()
        
        processed = 0
        for i in range(total):
            filepath = self.batch_listbox.get(i)
            try:
                img = Image.open(filepath)
                
                if operation == "Grayscale":
                    img = img.convert('L')
                elif operation == "Resize (50%)":
                    new_size = (img.width // 2, img.height // 2)
                    img = img.resize(new_size, RESAMPLE_FILTER)
                elif operation == "Blur":
                    img = img.filter(ImageFilter.GaussianBlur(radius=3))
                elif operation == "Sharpen":
                    img = img.filter(ImageFilter.SHARPEN)
                elif operation == "Edge Detect":
                    img = img.filter(ImageFilter.FIND_EDGES)
                elif operation == "Sepia":
                    img = img.convert('RGB')
                    pixels = img.load()
                    for x in range(img.width):
                        for y in range(img.height):
                            r, g, b = pixels[x, y]
                            tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                            tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                            tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                            pixels[x, y] = (min(255, tr), min(255, tg), min(255, tb))
                
                base_name = os.path.basename(filepath)
                output_path = os.path.join(output_dir, f"processed_{base_name}")
                img.save(output_path)
                
                processed += 1
                self.update_status(f"Processing: {processed}/{total}")
                
            except Exception as e:
                print(f"Error processing {filepath}: {e}")
        
        self.stop_progress()
        self.batch_info_label.config(text=f"Processed {processed}/{total} files. Saved to {output_dir}/")
        self.update_status(f"Batch processing complete: {processed} files")
        messagebox.showinfo("Complete", f"Processed {processed} images!\nSaved to: {output_dir}/")
        
    def display_image(self, img, canvas):
        canvas_width = canvas.winfo_width()
        canvas_height = canvas.winfo_height()
        
        if canvas_width <= 1:
            canvas_width = 500
        if canvas_height <= 1:
            canvas_height = 500
            
        img_copy = img.copy()
        img_copy.thumbnail((canvas_width - 20, canvas_height - 20), RESAMPLE_FILTER)
        
        photo = ImageTk.PhotoImage(img_copy)
        
        canvas.delete("all")
        canvas.create_image(canvas_width//2, canvas_height//2, image=photo)
        canvas.image = photo
        
    def update_status(self, message):
        self.status_label.config(text=message)
        self.root.update_idletasks()
        
    def start_progress(self):
        self.progress.start()
        
    def stop_progress(self):
        self.progress.stop()
    
    def cleanup_finished_processes(self):
        """Remove finished processes from the active list."""
        self.active_processes = [p for p in self.active_processes if p.is_alive()]
    
    def cleanup_temp_files(self):
        """Clean up temporary files created during processing."""
        temp_files = ["converted_image.jpg", "bw_image.jpg"]
        for temp_file in temp_files:
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except Exception as e:
                    print(f"Could not remove {temp_file}: {e}")
    
    def on_closing(self):
        """Handle application shutdown gracefully."""
        for process in self.active_processes:
            if process.is_alive():
                process.terminate()
                process.join(timeout=2)
        
        self.cleanup_temp_files()
        self.root.destroy()

def draw_with_turtle_process(image_path):
    """
    Standalone function to draw with Turtle Graphics in a separate process.
    This runs in its own process to avoid threading issues with Tkinter.
    """
    import turtle
    from PIL import Image
    import numpy as np
    
    screen = turtle.Screen()
    screen.setup(width=800, height=800)
    screen.title("Auto-Drawer - Turtle Graphics Animation")
    screen.bgcolor("white")
    
    pen = turtle.Turtle()
    pen.speed(0)
    pen.pensize(1)
    pen.hideturtle()
    
    img = Image.open(image_path)
    img_array = np.array(img)
    height, width = img_array.shape
    
    pen.penup()
    pen.goto(-width//2, height//2)
    
    screen.tracer(0)
    
    points_drawn = 0
    for y in range(0, height, 2):
        for x in range(0, width, 2):
            if img_array[y, x] > 128:
                pen.goto(x - width//2, height//2 - y)
                pen.pendown()
                pen.dot(2, "black")
                pen.penup()
                points_drawn += 1
                
                if points_drawn % 500 == 0:
                    screen.update()
    
    screen.update()
    pen.goto(0, -height//2 - 50)
    pen.write(f"Drawing complete! Drew {points_drawn} points", 
             align="center", font=("Arial", 12, "normal"))
    
    screen.mainloop()

def main():
    multiprocessing.freeze_support()
    root = tk.Tk()
    app = ImageToolkit(root)
    root.mainloop()

if __name__ == "__main__":
    main()
